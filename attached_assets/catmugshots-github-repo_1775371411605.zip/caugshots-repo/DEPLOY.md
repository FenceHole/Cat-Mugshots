# Deploy to GitHub

Paste this prompt into Claude Code:

---

I have a static website repo in the current directory. Please do the following:

1. Create a new public GitHub repository called `catmugshots` on my account using the GitHub API
2. Add the remote origin to this local git repo
3. Push the `main` branch to GitHub
4. Enable GitHub Pages on the repo so the site is live at my username.github.io/catmugshots — set the source to the root of the main branch

The repo already has a git history with two commits. Just add the remote and push.
