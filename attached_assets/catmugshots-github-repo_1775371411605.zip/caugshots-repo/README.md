# 🐱 Cat Mugshots

> Criminally cute mugs for tiny felons.

A polished marketing site for [Cat Mugshots](https://cool-cat-stuff.printify.me/) — a cat mugshot mug brand built around everyday feline crimes. The site acts as a premium brand front-end while routing all purchases directly to the live Printify store.

**Live site:** [catmugshots.github.io](https://catmugshots.github.io) *(update this once deployed)*

---

## What this is

- A **single-file static website** (`index.html`) — no build step, no dependencies, no backend
- All product images are embedded as base64 — the file is fully self-contained
- Every "Buy on Printify" button links directly to the matching live product page
- No cart, no checkout, no payment logic — Printify handles all of that

---

## Features

- 📰 Breaking news ticker from *The GOOD Meow*
- 🐱 Baxter Harrington, senior crime correspondent — peeks in from the right edge
- 👮 Officer Muffin, Sgt. Fluffkins, Officer Mittens & Cpl. Biscuits on patrol
- 🔴 GUILTY stamp hover effect on product cards
- 📌 **Crime Tip Line** — community board where visitors submit their cat's crimes, vote on suggestions, and top picks get reviewed for real mug production (persists via localStorage)

---

## Products (live Printify links)

| Design | Category | Sizes | Link |
|--------|----------|-------|------|
| 3AM Zoomies | Sleep Crime | 11oz / 15oz | [Buy](https://cool-cat-stuff.printify.me/product/18466062/3am-zoomies-cat-mug-shot-11oz15oz) |
| Sock Thief | Laundry Crime | 11oz / 15oz | [Buy](https://cool-cat-stuff.printify.me/product/18466399/sock-thief-cat-mug-shot-11oz15oz) |
| Scratched the Couch | Home Crime | 11oz / 15oz | [Buy](https://cool-cat-stuff.printify.me/product/18465893/scratched-the-couch-cat-mug-shot-11oz15oz) |
| Kicked Litter Across the State | Bathroom Crime | 11oz / 15oz | [Buy](https://cool-cat-stuff.printify.me/product/18464554/kicked-litter-across-the-state-cat-mug-shot-11oz15oz) |
| Bites the Hand That Feeds Her | Feeding Crime | 11oz | [Buy](https://cool-cat-stuff.printify.me/product/18871726/cool-cat-stuff-mug-bites-the-hand-that-feeds-her-funny-cat-mugshot) |
| Knocked Over the Christmas Tree | Holiday Crime | 11oz / 15oz | [Buy](https://cool-cat-stuff.printify.me/product/18466304/knocked-over-the-christmas-tree-cat-mug-shot-11oz15oz) |

---

## Deploying via GitHub Pages

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set source to **Deploy from a branch → main → / (root)**
4. Save — your site will be live at `https://YOUR-USERNAME.github.io/catmugshots`

---

## Adding new suspects

1. Add the product image to the `index.html` (base64 encoded, or swap to a hosted URL)
2. Add a new `<article class="card">` block in the product grid
3. Point the buy button to the new Printify product URL
4. File a new case number (increment from CS-0112)

---

## Stack

Pure HTML + CSS + vanilla JS. Zero dependencies. Zero build step. One file.

---

*All suspects guilty. Checkout handled securely by Printify. Reporting by The GOOD Meow.*
